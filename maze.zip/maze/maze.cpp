#include <vector>
#include <iostream>
#include <string>
#include <random>
#include <stack>
#include <queue>

#define DENSITY 5
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"

using namespace std;

int width;
int height;
int num;
int times=10;

//declare point
class Point
{
    public:
        int X;
        int Y;
    Point()=default;

    Point(int x, int y)
    {
        X = x;
        Y = y;
    }
    Point& operator= (const Point& point)
    {
        if (this == &point)
        {
            return *this;
        }

        X = point.X;
        Y = point.Y;

        return *this;
    }
    bool operator == (const Point& point) const
    {
        if (X == point.X && Y == point.Y)
        {
            return true;
        } else 
        {
            return false;
        }
    }
    bool operator != (const Point& point) const
    {
        return (X != point.X || Y != point.Y);
    }
    void print()
    {
        cout<<"("<<X<<","<<Y<<")"<<endl;
    }
};

//declare tree
class Treenode
{
public:
    Point p;
    vector<Treenode> p_vec;
    Treenode(Point p1):p(p1){};
    void push(Point p1){
        Treenode t(p1);
        p_vec.push_back(t);
    }
};

//print maze
void maze_print(const vector<vector<int> > &maze)
{
    for(int i = 0; i < height; i++)
    {
        for(int j = 0; j < width; j++)
        {
            if (maze[i][j] == 1)
            {
                cout<<YELLOW<<maze[i][j];
            }else if(maze[i][j] == 0){
                cout<<GREEN<<maze[i][j];
            }else{
                cout<<maze[i][j];
            }
        }
        cout<<endl;
    }   
}
vector<vector<int> > generate(int width, int height)
{
    mt19937 rng;
    rng.seed(random_device()());

    default_random_engine fixed;
    uniform_int_distribution<int> distribution(0, 9);

    vector<vector<int> > maze(height, vector<int>(width));
    for(int i = 0; i < height; i++)
    {
        for(int j = 0; j < width; j++)
        {
            maze[i][j] = distribution(rng) < DENSITY ? 1 : 0;
        }
    }
    return maze;
}


/*
find new points from p and put them in a vector
return if there are new points
*/
bool getpoints(Treenode& t,Point front,const vector<vector<int> > & maze)
{
    Point p=t.p;
    int x=p.X,y=p.Y;

    for(int i=x-1;i<x+2;i++){
        for(int j=y-1;j<y+2;j++){
            Point p2(i,j);
            if(p2!=p && p2!=front &&i>=0&&j>=0&&i<height && j<width && maze[i][j]==num){
                Treenode t1(p2);
                t.p_vec.push_back(t1);
            }
        }
    }
    if(t.p_vec.size()>0){return true;}
    return false;
}

//get front point except the first
Point getfront(stack<Treenode>& s)
{
    Treenode now=s.top();
    s.pop();
    if(s.empty()){
        return now.p;
    }else{
        return s.top().p;
    }
    s.push(now);
}

void s_print(stack<Treenode> s,vector<vector<int> > maze){
    Point p;
    while(!s.empty()){
        Treenode t(s.top());
        s.pop();
        p=t.p;
        maze[p.X][p.Y]=2;
    }
    maze_print(maze);
    cout<<endl;
}

/*
push points to stack and push stack into que 
*/
void pushpoints(Treenode t,stack<Treenode> s,queue<stack<Treenode> >& path_que)
{
    s.push(t);
    path_que.push(s);
}

/*
the num of right path is 2 and error path is 3 
bfs search the shortest path
*/
bool path(queue<stack<Treenode> >&path_que,Point start,Point end,vector<vector<int> > &maze,vector<stack<Treenode> >& pathofmaze)
{
    int x1=start.X,y1=start.Y,x2=end.X,y2=end.Y;
    //check if end is reachable
    if(maze[x1][y1]!=maze[x2][y2])
    {
        cout<<"the end can't reach"<<endl;
        return false;
    }

    bool pflag;//check if there are points
    stack<Treenode> s;
    while(!path_que.empty())
    {
        s=path_que.front();
        path_que.pop();
        Treenode t=s.top();
        s.push(t);
        Point front=getfront(s);
        pflag=getpoints(t,front,maze);
        for(int i=0;i<t.p_vec.size();i++){
            pushpoints(t.p_vec[i],s,path_que);
            if(t.p_vec[i].p==end){
                times--;
                pathofmaze.push_back(path_que.back());
                if(times==0){return true;}
            }
        }
    }
    return false;
}


int main()
{
    

    cout<<"Please input the width:";
    cin>>width;
    cout<<"Please input the height:";
    cin>>height;
    
    mt19937 rng;
    rng.seed(random_device()());

    uniform_int_distribution<int> distribution(0, 9);

    vector<vector<int> > maze = generate(width, height);
    maze_print(maze);

    cout<<"the start piont x,y:";
    int x1,x2,y1,y2;
    cin>>x1;
    cin>>y1;
    cout<<"the end piont x,y:";
    cin>>x2;
    cin>>y2;
    Point start(x1,y1);
    Point end(x2,y2);
    num=maze[x1][y1];
    Treenode root(start);
    stack<Treenode> path_sta;
    path_sta.push(root);
    queue<stack<Treenode> >path_que;
    path_que.push(path_sta);

    vector<stack<Treenode> > pathofmaze;
    bool flag=path(path_que,start,end,maze,pathofmaze);
    for(int i=0;i<pathofmaze.size();i++)
    {
        s_print(pathofmaze[i],maze);
    }
    //test
    

    return 0;
}
