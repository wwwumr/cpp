#include<iostream>  
#include<string> 

using namespace std;

double expression();
double term();
double single();
double primary(double val=0);
int fac(int val);

class Token  
{  
public:  
    Token(char ch):kind(ch){}  
    Token(char ch,double val):kind(ch),value(val){}  
    char kind;  
    double value;  
};

class Token_Stream  
{  
private:  
    Token buffer;  
    bool null;
public:
    Token_Stream():buffer('8',0),null(true){}  
    void push_back(Token t)
    {    
    buffer=t;  
    null=false;  
    }  
    Token get();  
};  
  
Token Token_Stream::get()  
{  
    if (!null)  
    {  
        null=true;  
        return buffer;  
    }
     
    char ch;  
    cin>>ch;  
    switch (ch)  
    {  
    case ';':case '+':case '-':case '*':case '/':case '(':case ')':case '%':
    case '!':
        return Token(ch);
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':case '6':case '7':case '8':case '9':  
        cin.putback(ch);    
        double val;  
        cin>>val;
        return Token('8',val);  
    default:  
        return Token(ch);  
    }  
}  
class err
{
public:
  int error=0;
};
err e;

Token_Stream ts;
  
int main()  
{  
    double val=0;
    cout << ">";   
    while (cin)  
    {  
        try  
        {   
            Token token=ts.get();
            if (token.kind == ';' )
            {
                if ( e.error==0)
                {
                    cout<<"="<<val<<endl;
                    cout << ">";
                }
            }
            else  
            {
                e.error = 0;
                ts.push_back(token);  
                val=expression();  
            }
        }    
        catch(...)  
        {  
            if (e.error!=0){
                cout<<"error"<<endl;
                cout << ">";
                e.error = 7;
            }
        }  
    }  
}  
 
  
double expression()  
{  
    double val=term(); 
    Token t=ts.get();  
    while(t.kind=='+'||t.kind=='-')  
    {  
        if(t.kind=='+')  
        {  
            val+=term();  
            t=ts.get();  
        }  
        if(t.kind=='-')  
        {  
            val-=term();  
            t=ts.get();  
        }  
    }  
    ts.push_back(t);  
    return val;  
}  
  
double term()  
{  
    double val=single();
    while (true)  
    {  
        Token token=ts.get();  
        switch (token.kind)  
        {
        case '*':  
            val*=single();
            break;  
        case '/':
            double a;
            a= single();
            if (a==0){
                e.error = 1;
                throw 1;
            }
            else
                val /= a;
            break;
        case '%':
            double b ;
            b= single();
            if(val!=(int)val || b!=(int)b){
                e.error = 2;
                throw 1;
            }else if(b==0){
                e.error = 3;
                throw 1;
            }else{
                int c = (int)val;
                int d = (int)b;
                val = c%d;
            }
            break; 
        default:  
            ts.push_back(token);
            return val;    
        }
    }  
}  
double single()
{
    double val = primary();
    Token token = ts.get();
    if (token.kind=='!')
    {
        if (int(val)==val){
            int a = (int)val;
            val=fac(a);
            return val;
        }else{
            e.error = 4;
            throw 1;
        }        
    }else{
       ts.push_back(token);
    }
    return val;
}
  
double primary(double val)  
{
    Token token=ts.get();  
    switch (token.kind)  
    {  
    case '8':
        val=token.value;  
        break;  
    case '(':  
        val=expression();
        token=ts.get();  
        if (token.kind!=')')
        {
            e.error = 5;
            throw 1;
        }
        break;
    case '+':
        val = primary();
        break;
    case '-':
        val = -primary();
        break;       
    default:
        e.error = 6;
        throw 1;
    }
    return val;  
}

int fac(int val)
{
    if (val==0){
        return 1;
    }else{
        int a = abs(val);
        return val*fac(a - 1);
    }
}    