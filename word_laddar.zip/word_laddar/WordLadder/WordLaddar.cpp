#include <iostream>
#include <fstream>
#include <string>
#include <queue>
#include <vector>
#include <map>
#include <stack>

using namespace std;

//declare function
bool push_word(stack<string> s,map<string,bool> m,string word,queue<stack<string> >& word_que,
    queue<map<string,bool> >& set_que);
bool getwords(stack<string> s,map<string,bool> m,const map<string,bool>& word_map,
    queue<stack<string> >& word_que,queue<map<string,bool> >& set_que);

//declare static name
string startw="";
string endw="";
string file_name;

//save words in a map;
void getm(map<string, bool>& word_map){
    ifstream in(file_name.c_str());
    //get lines
    string line;
    while(!in.eof()&&in){
        getline(in,line);
        word_map[line]=true;        
    }
}

//for all stack get new word
bool getsta(const map<string,bool>& word_map,queue<stack<string> >& word_que,queue<map<string,bool> >& set_que)
{
    bool flag=false;//check if you have found the path

    while(!word_que.empty() && !flag)
    {
        stack<string> sta=word_que.front();
        map<string,bool> m=set_que.front();
        word_que.pop();
        set_que.pop();
        //push new stack into word_que
        flag=getwords(sta,m,word_map,word_que,set_que);
    }
    if(word_que.back().top()==endw){
        return true;
    }else{
        return false;
    }
}

//get words changed from word
bool getwords(stack<string> s,map<string,bool> m,const map<string,bool>& word_map,
    queue<stack<string> >& word_que,queue<map<string,bool> >& set_que)
{
    string word=s.top(),word0;
    s.pop();
    if(!s.empty()){
        word0=s.top();//the privious word
    }else{
        word0=word;
    }
    s.push(word);

    string word1;
    bool flag=false;//check if there are any possible words 
    for(int i=0;i<word.length();i++)
    {
        word1=word;
        for(char j='a';j<='z';j++){
            word1[i]=j;  
            if(word_map.count(word1)>0 ){
                if(m.count(word1)<=0){
                    flag=true;
                    push_word(s,m,word1,word_que,set_que);
                    if(word1== endw){return true;}//check if get the end
                }  
            }
        }
    }
    return false;
}

//put elements into stack
bool push_word(stack<string> s,map<string,bool> m,string word,queue<stack<string> >& word_que,
    queue<map<string,bool> >& set_que)
{
    s.push(word);   
    m[word]=true;
    word_que.push(s);
    set_que.push(m);
}


//check if the start word and the end word are valid
int check(const map<string,bool>& word_map)
{
    if(word_map.count(startw)<=0 || word_map.count(endw)<=0){
        cout<<"the words that you input are not in dict";
        return 0;
    }
    if(startw==endw){
        cout<<"the two words are the same";
        return 1;
    }
    if(startw.length()!=endw.length())
    {
        cout<<"the length of two words are different";
        return 2;
    }
    return 3;
}

//print the path
void target_print(stack<string> target)
{
    string point;
    stack<string> s;
    while(!target.empty()){
        point=target.top();
        target.pop();
        s.push(point);
    }
    while(!s.empty()){
        point=s.top();
        s.pop();
        cout<<point;
        if(!s.empty()){cout<<"->";}
    }
}
int main()
{
    /*cout<<"please input the location of the dictionary:";
    cin>>file_name;*/
    file_name="D:/program/c++/.vscode/word_laddar/serafini_starter/Wordladdar/res/dictionary.txt";
    cout<<"please input the start word:";
    cin>>startw;
    cout<<"please input the end word:";
    cin>>endw;

    queue<stack<string> > word_que;//save possible path
    queue<map<string,bool> > set_que;//save the words in the coresponding stack
    stack<string> root;//the root word of the tree
    map<string,bool> m;//the first map
    root.push(startw);
    m[startw]=true;
    word_que.push(root);//word_que over
    set_que.push(m);//set_que over
    stack<string> target;
    bool flag;//the shortest path

    map<string,bool> word_map;//wordlist
    getm(word_map);

    //check if the input has error
    int error=check(word_map);
    if(error!=3){return 0;}

    flag=getsta(word_map,word_que,set_que);
    if(flag){
        target=word_que.back();
    }else{
        cout<<"there is no path";
        return 0;
    }

    target_print(target);

    return 0;
}
    