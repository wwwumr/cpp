#include <string>
#include "program.h"
#include "statement.h"
using namespace std;


/*
*this class is created to save lines in it
*and process the whole program
*/
Program::Program() {
   location=0;
}

Program::~Program() {
   for(int i=0;i<lines.size();i++)
   {
       delete myProgram[i];
   }
}

//clear the program
void Program::clear(EvalState& state) {
    location= 0 ;
    state.clear();
    lines.clear();
    stringCode.clear();
    myProgram.clear();
}

//add one line or change one line
void Program::addSourceLine(int lineNumber, string line,Statement* arguement) {
    int n=lines.size(); 
    //insert new line by sort 
    for(int i=0;i<n;i++)
    {
        if(lines[i]>lineNumber){
            lines.insert(lines.begin()+i,lineNumber);
            stringCode.insert(stringCode.begin()+i,line);
            myProgram.insert(myProgram.begin()+i,arguement);
            break;
        }else if(lines[i]==lineNumber){//if it has been initial
            stringCode[i]=line;
            myProgram[i]=arguement;
            break;
        }
        if(i==n-1){//new line is the bigest one
        lines.push_back(lineNumber);
        stringCode.push_back(line);
        myProgram.push_back(arguement);
        }
    }
    if(n==0){//no lines yet
        lines.push_back(lineNumber);
        stringCode.push_back(line);
        myProgram.push_back(arguement); 
    }
}

//remove one line by line number
void Program::removeSourceLine(int lineNumber) {
    for(int i=0;i<lines.size();i++)
    {
        if(lines[i]==lineNumber){
            if(i<location){location--;}
            lines.erase(lines.begin()+i,lines.begin()+i+1);
            stringCode.erase(stringCode.begin()+i,stringCode.begin()+i+1);
            delete myProgram[i];
            myProgram.erase(myProgram.begin()+i,myProgram.begin()+i+1);
        }
    }
}

//print the source lines
string Program::getSourceLine(int lineNumber) {
    int n;
    for(int i=0;i<lines.size();i++)
    {
        if(lines[i]==lineNumber){
            n=i;
        }
    }
    string str=stringCode[n];
    cout<<str<<endl; 
    return str;
}

//process one line in the form of c++ program
bool Program::runLine(int lineNumber,EvalState& state)
{   
    string str=myProgram[location]->getKey();
    if(str=="END"){return false;}
    if(myProgram[location]!=NULL ){
        myProgram[location]->execute(state,*this);//
    }
    return true;
}

//renew the location to control the procession of program
void Program::getLocation(int lineNumber)
{
    for(int i=0;i< lines.size();i++)
    {
        if(lines[i]==lineNumber)
        {
            location=i-1;
            return ;
        }
    }
    throw 4;
}

//get the size of the program
int Program::numberOfLine()
{
    return lines.size();
}

//start the program when get the instruction RUN
void Program::runCode(EvalState& state)
{
    int n=lines.size();
    bool toBeContinue=true;
    for(location=0;location<n;location++)
    {
        toBeContinue=runLine(lines[location],state);
        if(!toBeContinue){break;}
    }
}

//get line number by location
int Program::getLinenumber(int n)
{
    return lines[n];
}