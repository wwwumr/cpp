#ifndef _statement_h
#define _statement_h

#include<string>
#include "../StanfordCPPLib/tokenscanner.h"
#include "program.h"
#include "evalstate.h"
#include "exp.h"

class Program;

class Statement {

public:
  
    Statement();

    virtual ~Statement();

    virtual std::string getKey()=0; 

    virtual void execute(EvalState & state,Program& pro) =0;

};


class Sequential:public Statement
{
  public:
    Sequential(std::string key,TokenScanner& scanner);

    virtual void execute(EvalState & state,Program& pro);

    std::string getKey(); 

    virtual ~Sequential();

  private:
    std::string str; 
    Expression* exp;
    string keyword;
};

class Control:public Statement
{
  public:
    Control(string key,TokenScanner& scanner);

    virtual void execute(EvalState& state,Program& pro);

    std::string getKey(); 

    virtual ~Control();

  private:
    int nextLine;
    std::string keyword;
    Expression* exp;

};

class Interpreter:public Statement
{
  public:
    Interpreter(std::string str);
    
    
    virtual void execute(EvalState& state,Program& pro);

    std::string getKey(); 

    virtual ~Interpreter();
  private:
    std::string keyword;

};



#endif
