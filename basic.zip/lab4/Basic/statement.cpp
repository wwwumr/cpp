#include <string>
#include<stack>

#include "parser.h"
#include "program.h"
#include "statement.h"
#include "../StanfordCPPLib/tokenscanner.h"
#include "evalstate.h"
#include "exp.h"

using namespace std;

/*
*this abstract type is created to process instructions
*children:Sequential Control Interpreter
*/

Statement::Statement() {}

Statement::~Statement() {}


/*
*the class that process Sequential instructions
*fuctions:getKey execute
*/
Sequential::Sequential(string key,TokenScanner& scanner) 
{
    keyword=key;
    exp=NULL;
    if(scanner.hasMoreTokens()&& keyword!="REM" && keyword!="END")
    {
        str=scanner.nextToken();
        if(scanner.hasMoreTokens())
        {
            scanner.saveToken(str);
            exp = parseExp(scanner);
        }
    }    
}

//get the keyword
string Sequential::getKey(){
    return keyword;
}

//process the Sequential instructions in the form of c++ program
void Sequential::execute(EvalState & state,Program& pro)
{
    if(keyword=="LET")
    {
        int value = exp->eval(state);
    }else if(keyword=="INPUT")
    {
        cout<<" ? ";
        int val;
        cin>>val;
        if(cin.fail()){throw 4;}
        state.setValue(str,val);
    }else if(keyword=="PRINT")
    {
        if(exp!=NULL){
            int value = exp->eval(state);
            cout<<value<<endl;
        }else if(str[0]=='0'||str[0]=='1'||str[0]=='2'||str[0]=='3'||str[0]=='4'||
        str[0]=='5'||str[0]=='6'||str[0]=='7'||str[0]=='8'||str[0]=='9'){
            cout<<str<<endl; 
        }else{
            cout<< state.getValue(str)<<endl;
        } 
    }
}

Sequential::~Sequential()
{
    delete exp;
}

/*
*the class that process Control instructions
*fuctions:getKey execute
*/
Control::Control(string key,TokenScanner& scanner)
{
    nextLine=-1;
    keyword=key;
    exp=NULL;
    if(key=="IF"){
        TokenScanner scan;
        scan.ignoreWhitespace();
        scan.scanNumbers();
        stack<string> sta;
        while(true){
            string str=scanner.nextToken();
            if(!scanner.hasMoreTokens()){break;}
            if(str=="THEN"){
                str=scanner.nextToken();
                nextLine=stringToInteger(str);
                break;
            }
            sta.push(str);
        }
        while(!sta.empty()){
            scan.saveToken(sta.top());
            sta.pop();
        }
        exp=parseExp(scan);
    }else if(keyword=="GOTO")
    {
        string str=scanner.nextToken();
        nextLine=stringToInteger(str);
    }
}

//get the keyword
string Control::getKey(){
    return keyword;
}

//process the Control instructions in the form of c++ program
void Control::execute(EvalState& state,Program& pro)
{
    if(exp==NULL){
        pro.getLocation(nextLine);
    }else{
        int value=exp->eval(state,1);
        if(value==1){
            pro.getLocation(nextLine);
        }else if(value!=0){
            throw 5;
        }
    }
}

Control::~Control()
{
    delete exp;
}

/*
*the class that process Interpreter instructions
*fuctions:getKey execute
*/
Interpreter::Interpreter(string str)
{
    keyword=str;
}

//get the keyword
string Interpreter::getKey(){
    return keyword;
}

//process the Interpreter instructions in the form of c++ program
void Interpreter::execute(EvalState& state,Program& pro)
{
    if(keyword=="QUIT"){exit(0);}
    else if(keyword=="LIST"){
        int n=pro.numberOfLine();
        for(int i=0;i<n;i++)
        {
            int j=pro.getLinenumber(i);
            pro.getSourceLine(j);
        }
    }else if(keyword=="RUN"){
        pro.runCode(state);
    }else if(keyword=="CLEAR")
    {
        pro.clear(state);
    }else if(keyword=="HELP"){
        cout<<"This program is a BASIC interpreter"<<endl;
        cout<<"You can use the instructions:"<<endl;
        cout<<"---------------------------------------"<<endl;
        cout<<"Sequential operation:"<<endl;
        cout<<"REM: it means the reminder"<<endl;
        cout<<"LET: it can assign the result to the var"<<endl;
        cout<<"PRINT: it can print the result of your expression"<<endl;
        cout<<"END: it indicates the end of the program"<<endl;
        cout<<"INPUT: it can assign the value you input to the var"<<endl;
        cout<<"---------------------------------------"<<endl;
        cout<<"Control operation:"<<endl;
        cout<<"IF exp cmp exp THEN nextLineNumber: if true go to nextLineNumber"<<endl;
        cout<<"GOTO nextLineNumber: goto the line which is after the \"GOTO\" "<<endl;
        cout<<"---------------------------------------"<<endl;
        cout<<"Interpreter operation:"<<endl;
        cout<<"RUN: start the program"<<endl;
        cout<<"LIST: it will print the whole program"<<endl;
        cout<<"QUIT: end this program"<<endl;
        cout<<"CLEAR: it will renew this program "<<endl;

    }

}

Interpreter::~Interpreter(){}



