#include <cctype>
#include<sstream>
#include <iostream>
#include <string>
#include "exp.h"
#include "parser.h"
#include "program.h"
#include "statement.h"
#include "../StanfordCPPLib/tokenscanner.h"
#include "../StanfordCPPLib/simpio.h"
#include "../StanfordCPPLib/strlib.h"

using namespace std;

 
void processLine(string line, Program & pro, EvalState & state);
void saveCode(Program& pro,TokenScanner& scanner, EvalState & state,string line);

/*
*this fuction will read a line one by one and process them 
*class:Program Evalstate Expression Statement and their children
*/
int main() {
   EvalState state;//save varieties
   Program pro;
   while (true) {
      try {
         processLine(getLine(), pro, state);
      } catch (int i) {
          //the type of error
          if(i==1){cout<<"DIVIDE BY ZERO"<<endl;}
          if(i==2){cout<<"INVALID NUMBER"<<endl;}
          if(i==3){cout << "VARIABLE NOT DEFINED" << endl;}
          if(i==4){cout<<"LINE NUMBER ERROR"<<endl;}          
          if(i==5){cout << "SYNTAX ERROR" << endl;}
      }
   }
   return 0;
}


void processLine(string line, Program & pro, EvalState & state) {
    //set scanner to read the whole line
    TokenScanner scanner;
    scanner.ignoreWhitespace();
    scanner.scanNumbers();
    scanner.setInput(line);

    //process the line and turn the line into program
    saveCode(pro,scanner,state,line);
   
}

void saveCode(Program& pro,TokenScanner& scanner, EvalState & state,string line)
{
    string str=scanner.nextToken();
    TokenType t=scanner.getTokenType(str);
    //if the first string the interpreter get if a word  
    if(t==WORD){
        //these instructions will conduct at once
        if(str=="LET"||str=="INPUT"||str=="PRINT")
        {
            Statement* s=new Sequential(str,scanner);
            s->execute(state,pro);
            delete s;
        }else if(str=="RUN"||str=="LIST"||str=="QUIT"||str=="CLEAR"||str=="HELP")
        {
            Statement* inter = new Interpreter(str); 
            inter->execute(state,pro);
            delete inter;
        }
    }else if(t==NUMBER)
    {
        //these instructions will be saved into program and run

        //get the line number
        int num=stringToInteger(str);
        //check whether there are instructions if not then delete the line
        if(!scanner.hasMoreTokens()){
            pro.removeSourceLine(num);
            return ;
        }
        //when there are instructions after the line number
        string arguement=scanner.nextToken();
        TokenType t1=scanner.getTokenType(arguement);
        if(t1==WORD){
            //get instructions
            if(arguement=="LET"||arguement=="INPUT"||arguement=="PRINT"||
            arguement=="REM"||arguement=="END")
            {
                Statement* s=new Sequential(arguement,scanner);
                pro.addSourceLine(num,line,s);
            }else if(arguement=="IF"||arguement=="GOTO")
            {
                Statement* c=new Control(arguement,scanner);
                pro.addSourceLine(num,line,c);
            }
        }else{
            throw 5;
        }
    }else if(str==""){
        //when he didn't input anything 
    }else{
        throw 5;
    }
}
