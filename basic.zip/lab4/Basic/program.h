#ifndef _program_h
#define _program_h

#include <string>
#include<vector>
#include "statement.h"


class Statement;

class Program {

public:

    Program();

    ~Program();

    void clear(EvalState& state);

    void addSourceLine(int lineNumber, std::string line,Statement* arguement);

    void removeSourceLine(int lineNumber);

    std::string getSourceLine(int lineNumber);

    bool runLine(int lineNumber, EvalState& state);

    void getLocation(int lineNumber);

    int numberOfLine();

    void runCode(EvalState& state);

    int getLinenumber(int n);

    int location;
private:

    vector<Statement*> myProgram;
    vector<std::string> stringCode;
    vector<int> lines;
    
};



#endif
