#include <string>
#include "evalstate.h"
#include "../StanfordCPPLib/map.h"
using namespace std;

/* 
*Implementation of the EvalState class 
*this class is created to save the value of variables
*/

EvalState::EvalState() {}

EvalState::~EvalState() {}

//set new var into map
void EvalState::setValue(string var, int value) {
    if(var=="LET"||var=="PRINT"||var=="REM"||var=="INPUT"||var=="END"||
    var=="IF"||var=="THEN"||var=="GOTO"||var=="RUN"||var=="LIST"||var=="QUIT"||
    var=="HELP"||var=="CLEAR"){
        throw 5;
    }
    symbolTable.put(var, value);
}

//get value from map
int EvalState::getValue(string var) {
    if(isDefined(var)){
        return symbolTable.get(var);
    }else{
        throw 3;
    }
}

//check if var has been defined
bool EvalState::isDefined(string var) {
   return symbolTable.containsKey(var);
}

//clear the map when get the CLEAR instruction
void EvalState::clear()
{
    symbolTable.clear();
}