#ifndef BTF_H
#define BTF_H

#include <fstream>
#include <string>
#include <vector>
#include "node.h"

/*--------------------------------------------------------------------
*BPlusTree
*main function: find() findRange() insert() remove() modify()
*this class is used to build index file and manage it
*/
class BPlusTree
{
private:
	std::string indexPath;
    std::fstream fs;
    int root;
public:
	BPlusTree(std::string indexPath);
	~BPlusTree();

	//display index file in the test.txt
	void copy(std::string outfile);
	//get the offset and length of the data.txt 
    Data find(int key);
	//get the leafNode of the key and pos is used for recursion
	LeafNode* findNode(int key,int pos);
	//insert new key and data if the key is there then modify the data
	bool insert(Data);
	//split one node into two and set node message return the middle key
	void split(Node message);
	//rotate and change the parent postion after insert
	bool leftRotate(Node message);
	bool rightRotate(Node message);
	//set parent:for the most left node to set parent
	void setParent(Node node);
	//set children to change their parent
	void setChildren(Node node,Node parent);
	//remove data or return (-1,-1)
	Data remove(int key);
	//merge node into left node when can't rotate and set parent children brother
	bool merge(Node node);
	//modify the data which is in btree or return false otherwise
    bool modify(Data data);
	//find range 
	std::vector<Data> findRange(int low, int high);

	int getRoot() { return root; }
};

#endif