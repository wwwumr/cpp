#ifndef _CACHE_H
#define _CACHE_H
#include <string>
#include<queue>
#include <map>

//declare max size
const int CacheSize=100;
/*
class Cahe is a class to sotre <key,value> which is just used 
function:getSize() find(int key) push(pair<int, string> newpair) clear()
*/
//-----------------------------------------------------------------------
class Cache {
private:
	// store data 
	std::queue<int> keys;
	std::map<int, std::string> CacheMap;
public:
	//get the size of map
	int getSize() const;
	/// find a data in cache 
	std::string find(int key);
	// The data entering the buffer must be refresh in Cache 
	void push(int key,std::string data);
	// clear the cache 
	void clear();
	//print
	void print();
};
//-----------------------------------------------------------------------
#endif