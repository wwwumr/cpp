#include<iostream>
#include<cstdlib>
#include<ctime>
#include"node.h"
#include"bpt.h"
#include"cache.h"
#include"data.h"
#include"freebin.h"

using namespace std;

string randStr(){
    string str="";
    int len=rand()%5+1;
    for(int i=0;i<len;i++){
        str+='a'+rand()%26;
    }
    return str;
}

int main()
{
    string indexFile="./data/index.txt";
    string dataFile="./data/data.txt";
    DataBase db(indexFile,dataFile);
    for(int i=0;i<1000000;i++){
        string str=randStr();
        db.insert(i,str);
    }
    cout<<"--------------find-test-----------"<<endl;
    for(int i=0;i<50;i++){
        int num=rand()%999999+1;
        string str=db.find(i);
        cout<<i<<":"<<str<<endl;
    }
    cout<<"--------------remove-test-----------"<<endl;
    for(int i=0;i<20;i++){
        int num=rand()%999999+1;
        cout<<db.find(num)<<":";
        db.remove(num);
        cout<<db.find(num)<<endl;
    }
    cout<<"--------------modify-test-----------"<<endl;
    for(int i=0;i<20;i++){
        int num=rand()%999999+1;
        cout<<db.find(num)<<":";
        db.modify(num,randStr()); 
        cout<<db.find(num)<<endl;
    }
}