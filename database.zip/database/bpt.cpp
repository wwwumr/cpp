#include <fstream>
#include<iostream>
#include <string>
#include <vector>
#include "node.h"
#include "bpt.h"

using namespace std;

BPlusTree::BPlusTree(string indexfile)
{
    indexPath=indexfile;
    fs.open(indexfile.c_str(),ios::binary|ios::in|ios::out|ios::app);
    fs.close();
    fs.open(indexfile.c_str(),ios::binary|ios::in|ios::out);
    fs.seekg(0,fs.end);
    int textLength=fs.tellg();
    fs.seekp(0,fs.beg);
    if(textLength==0){
        root=sizeof(int);
        fs.write(reinterpret_cast<char*>(&root),sizeof(int));
        LeafNode* l=new LeafNode;
        Node n;
        n.position=root;
        l->setMessage(n);
        l->rewrite(fs);
        delete l;
    }else{
        fs.seekg(0,fs.beg); 
        fs.read(reinterpret_cast<char*>(&root),sizeof(int));
    }
}

BPlusTree::~BPlusTree(){
    fs.seekp(0);
    fs.write(reinterpret_cast<char*>(&root),sizeof(int));
    fs.close();
}

void BPlusTree::copy(string outfile){
    fstream outfs(outfile.c_str(),ios::out|ios::app);
    outfs.close();
    outfs.open(outfile.c_str(),ios::out); 
    fs.seekg(0,fs.end);
    int textLength=fs.tellg();
    fs.seekg(0,fs.beg);
    outfs.seekp(0,outfs.beg);
    
    for(int i=0;i<textLength/sizeof(int);i++){
        int x=0;
        fs.read(reinterpret_cast<char*>(&x),sizeof(int));
        outfs<<x;
    }
}

Data BPlusTree::find(int key){
    LeafNode* leaf = findNode(key,root);
	int pos = leaf->findKey(key);
	if (pos == -1){return Data(-1,-1,0);}

    Data data=leaf->getData(pos);
    delete leaf;
	return Data(key,data.offset,data.length); 
}

LeafNode* BPlusTree::findNode(int key,int pos){
    if(fs.eof()){
        fs.clear();    
        fs.seekg(0,fs.beg);
    }
    fs.seekg(pos);
    Node_Type type;
    fs.read(reinterpret_cast<char*>(&type),sizeof(int));

    if(type==MIDDLE){
        MiddleNode* m=new MiddleNode(fs,pos);
        int n=m->findPosition(key);
        int nextPos=m->getOffset(n);
        if(nextPos==-1){
            cout<<"bpt::findnode::nextpos error"<<endl;
            delete m;
            return NULL;
        }
        delete m;
        return findNode(key,nextPos);
    }else if(type==LEAF){
        LeafNode* l=new LeafNode(fs,pos);        
        return l;
    }else{
        cout<<"bpt::findnode::type error"<<endl; 
        return NULL;
    }
}

bool BPlusTree::insert(Data data){
    int key=data.key; 
    LeafNode* l=findNode(key,root);
    if(l==NULL){
        cout<<"bpt::insert::type error"<<endl;
        return false;
    }
    if(data.key<0||data.offset<0||data.length<=0){
        cout<<"bpt::insert::insert data error"<<endl;
        return false;
    }

    int keyNum=l->findKey(key);
    //have the key
    if(keyNum!=-1){
        l->modify(keyNum,data);
        l->rewrite(fs);
        delete l;
        return true;
    }
    //don't have the key
    Node m=l->getMessage();
    if(m.size<LMAX){
        int suitPos=l->findPosition(key);
        l->insert(suitPos,data);
        l->rewrite(fs);
        if(suitPos==0){
            m.size++;
            setParent(m);
        }
        delete l; 
        return true;
    }
    //if rotation is possible
    if(fs.fail()){fs.clear();}
    int num=l->findPosition(data.key);
    l->insert(num,data);
    l->rewrite(fs); 
    bool flag=leftRotate(m);
    if(flag){
        delete l;
        return true;
    }
    flag=rightRotate(m);
    if(flag){
        delete l;
        return true;
    }
    //split node
    Node n=l->getMessage();
    delete l;
    split(n);
    return true;
}

bool BPlusTree::leftRotate(Node message){
    //check
    if(message.parent<0||message.position<0||message.leftSibling<0){return false;}

    //init nodes
    TreeNode* leftNode;
    TreeNode* rightNode;
    TreeNode* parentNode=new MiddleNode(fs,message.parent);
    if(message.type==MIDDLE){
        leftNode=new MiddleNode(fs,message.leftSibling);
        rightNode=new MiddleNode(fs,message.position);    
    }else if(message.type==LEAF){
        leftNode=new LeafNode(fs,message.leftSibling);
        rightNode=new LeafNode(fs,message.position);
    }else{
        cout<<"bpt::leftrotate::type error"<<endl;
        return false;
    }

    Node lm=leftNode->getMessage();
    //check if sibling is full 
    int max= ((message.type==MIDDLE)? MMAX:LMAX);  
    if(lm.size>=max || message.size<=(max+1)/2||message.parent!=lm.parent){
        delete leftNode;
        delete rightNode;
        delete parentNode;
        return false;
    }
    //rotate
    if(message.type==LEAF){
        Data myData=rightNode->remove(0);
        leftNode->insert(lm.size,myData);
    }else if(message.type==MIDDLE){
        int key=rightNode->removeKey(0);
        int offset=rightNode->removeOffset(1);
        leftNode->insertKey(lm.size,key);
        leftNode->insertOffset(lm.size+1,offset);
        Node newSon(fs,offset);
        setChildren(newSon,lm); 
    }else{
        cout<<"bpt::leftprtate::type error"<<endl;
    }
    rightNode->rewrite(fs);
    leftNode->rewrite(fs);
    setParent(rightNode->getMessage()); 
    delete leftNode;
    delete rightNode;
    delete parentNode;
    return true;     
}


bool BPlusTree::rightRotate(Node message){
    //check relative
    if(message.parent<0||message.position<0||message.rightSibling<0){return false;}
    
    //init nodes
    TreeNode* leftNode;
    TreeNode* rightNode;
    TreeNode* parentNode=new MiddleNode(fs,message.parent);
    if(message.type==MIDDLE){
        leftNode=new MiddleNode(fs,message.position);
        rightNode=new MiddleNode(fs,message.rightSibling);    
    }else if(message.type==LEAF){
        leftNode=new LeafNode(fs,message.position);
        rightNode=new LeafNode(fs,message.rightSibling);
    }else{
        cout<<"bpt::rightrotate::type error"<<endl;
        return false;
    }

    Node rm=rightNode->getMessage();
    //check if sibling is full
    int max= ((message.type==MIDDLE)? MMAX:LMAX);  
    if(rm.size>=max || message.size<= (max+1)/2 || message.parent!= rm.parent){
        delete leftNode;
        delete rightNode;
        delete parentNode;
        return false;
    }
    //rotate
    if(message.type==LEAF){
        Data myData=leftNode->remove(message.size);
        rightNode->insert(0,myData);
    }else if(message.type==MIDDLE){
        int key=leftNode->removeKey(message.size);
        int offset=leftNode->removeOffset(message.size+1);
        rightNode->insertKey(0,key);
        rightNode->insertOffset(1,offset);
        Node newSon(fs,offset); 
        setChildren(newSon,rm);  
    }else{
        cout<<"bpt::rightrotate::type error"<<endl;
        return false;
    }
    rightNode->rewrite(fs);
    leftNode->rewrite(fs);
    setParent(rightNode->getMessage());
    delete leftNode;
    delete rightNode;
    delete parentNode;
    return true;     
}


void BPlusTree::setParent(Node node){
    //check if has parent
    if(node.parent==-1){return;} 
    //check if it is the first key's right offset
    MiddleNode* par=new MiddleNode(fs,node.parent);
    int offsetPos=par->findOffset(node.position);
    if(offsetPos==0){return;}
    if(offsetPos==-1){
        cout<<"bpt::setparent::parent doesn't have this offset"<<endl;
        return ;
    }
    //change the first key and set his parent
    if(node.type==MIDDLE){
        MiddleNode* n=new MiddleNode(fs,node.position);
        par->modifyKey(offsetPos-1,n->getKey(0));
        par->rewrite(fs);
        
        delete n;
        if(offsetPos==1){
            setParent(par->getMessage());
        }
        delete par;
    }else{
        LeafNode* n=new LeafNode(fs,node.position);
        par->modifyKey(offsetPos-1,n->getData(0).key);
        par->rewrite(fs);
        delete n;
        if(offsetPos==1){
            setParent(par->getMessage());
        }
        delete par;
    }
}

void BPlusTree::setChildren(Node node,Node parent)
{    
    TreeNode* child=new TreeNode(fs,node.position);
    node.parent=parent.position;
    child->setMessage(node);
    child->rewriteMessage(fs);
    delete child;  
}

void BPlusTree::split(Node message){ 
    //check parent exists or not
    Node parent(fs,message.parent);
    if(parent.position<0){
        TreeNode* parentNode=new MiddleNode();
        fs.clear();
        fs.seekg(0,fs.end);
        Node n;
        n.position=fs.tellg();
        root=n.position;
        n.type=MIDDLE;
        //create parent
        parentNode->setMessage(n);
        message.parent=n.position;
        root=n.position; 
        message.rewrite(fs); 
        parentNode->insertOffset(0,message.position);
        parentNode->rewrite(fs);
        split(message);
        delete parentNode;
        return ;
    }
    //check parent is full or not
    if(parent.size==MMAX){
        MiddleNode* parentNode=new MiddleNode(fs,message.parent);
        TreeNode* oldNode;
        int key,offset;
        //insert new key and offset
        if(message.type==MIDDLE){
            oldNode=new MiddleNode(fs,message.position);
            key=oldNode->getKey((MMAX+1)/2);
            offset=message.position;
        }else{
            oldNode=new LeafNode(fs,message.position);
            Data d=oldNode->getData((LMAX+1)/2);
            key=d.key;
            offset=d.offset;
        }
        delete oldNode;
        int keyPos=parentNode->findPosition(key);
        parentNode->insertKey(keyPos,key);
        parentNode->insertOffset(keyPos+1,offset);
        parentNode->rewrite(fs);
        split(message);
        split(parentNode->getMessage());
        delete parentNode;
        return ;
    }else if(parent.size==MMAX+1){
        MiddleNode* parentNode=new MiddleNode(fs,message.parent);
        parentNode->removeKey(MMAX);
        parentNode->removeOffset(MMAX+1);
        parentNode->rewrite(fs);
        delete parentNode;
    }else if(parent.size>MMAX+1){
        cout<<"bpt::split::parent size is overflow"<<endl;
        return ;
    }
    //check node if full or not
    int max=(message.type==MIDDLE)? MMAX+1 :LMAX+1;
    if(message.size==max){
        fs.seekg(0,fs.end);
        int position=fs.tellg();
        if(message.type==MIDDLE){
            //create new node and set brother
            TreeNode* oldNode=new MiddleNode(fs,message.position);
            vector<int> keys(max,-1);
            vector<int> offsets(max+1,-1);
            offsets[0]=-1;
            for(int i=0;i<max/2;i++){
                keys[max/2-i-1]=oldNode->removeKey(max-1-i);
                offsets[max/2-i]=oldNode->removeOffset(max-i);
            }
            Node n(message.type,position,parent.position,message.position,message.rightSibling,max/2);
            n.rewrite(fs);
            message.rightSibling=position;
            message.size=max-max/2;
            message.rewrite(fs);
            TreeNode* newNode=new MiddleNode(n,keys,offsets);
            oldNode->setMessage(message);
            oldNode->rewrite(fs);
            newNode->rewrite(fs);
            //set parent
            MiddleNode* parentNode=new MiddleNode(fs,message.parent);
            int keyPos=parentNode->findPosition(keys[0]);
            parentNode->insertKey(keyPos,keys[0]);
            parentNode->insertOffset(keyPos+1,position);
            parentNode->rewrite(fs);
            //change children's parent
            for(int i=0;i<offsets.size();i++){
                int pos=offsets[i];
                if(pos!=-1){
                    Node node(fs,pos);
                    setChildren(node,n);
                }  
            }
            delete parentNode;
            delete oldNode;
            delete newNode;
            return ;
        }else{
            TreeNode* oldNode=new LeafNode(fs,message.position);
            vector<Data> datas(max,Data(-1,-1,0));
            for(int i=0;i<max/2;i++){
                datas[max/2-i-1]=oldNode->remove(max-i-1);
            }
            Node n(message.type,position,parent.position,message.position,message.rightSibling,max/2);
            message.rightSibling=position;
            message.size=max-max/2;
            message.rewrite(fs);
            n.rewrite(fs);
            TreeNode* newNode=new LeafNode(n,datas);
            oldNode->setMessage(message);
            newNode->rewrite(fs);
            oldNode->rewrite(fs);
            //set parent
            MiddleNode* parentNode=new MiddleNode(fs,message.parent);
            int keyPos=parentNode->findPosition(datas[0].key);
            parentNode->insertKey(keyPos,datas[0].key);
            parentNode->insertOffset(keyPos+1,position);
            parentNode->rewrite(fs);
            delete parentNode;
            delete oldNode;
            delete newNode;
            return ;
        }  
    }else if(message.size>max){
        cout<<"bpt::split::node size is larger than max"<<endl;
        return;
    }else{
        cout<<"bpt::split::node size is too small to split"<<endl;
        return ;
    }
}


Data BPlusTree::remove(int key){
    LeafNode* target=findNode(key,root);
    //check if can find this node
    if(target==NULL){
        cout<<"remove node error"<<endl;
        delete target;
        return Data(-1,-1,0);
    }
    //check if has this key
    int keyNum=target->findKey(key);
    if(keyNum==-1){
        delete target;
        return Data(-1,-1,0);
    }
    //check node size
    Node node=target->getMessage();
    int max=((node.type==MIDDLE)?MMAX+1:LMAX+1);
    if(node.size>max/2){
        Data data=target->remove(keyNum);
        target->rewrite(fs);
        setParent(node); 
        delete target;
        return data;
    }

    int pos=target->getMessage().position;
    Data data=target->remove(keyNum);
    target->rewrite(fs);
    if(keyNum==0){setParent(target->getMessage());}
    bool flag=false;
    if(node.leftSibling>0){
        flag=rightRotate(Node(fs,node.leftSibling));
    }
    if(!flag && node.rightSibling>0){
        //can't rightRotate so merge left
        flag=leftRotate(Node(fs,node.rightSibling));
    }
    if(flag){
        //rotation is over
        delete target;
        target=new LeafNode(fs,pos);
        delete target;
        return data;  
    }
    //can't rotate then merge nodes
    flag=merge(target->getMessage());
    if(!flag){
        merge(Node(fs,node.rightSibling));
    }
    delete target;
    return Data(key,data.offset,data.length);
}

bool BPlusTree::merge(Node node)
{ 
    int max=(node.type==MIDDLE)?MMAX+1:LMAX+1;
    //check parent and left brother
    if(node.parent<0||node.leftSibling<0){return false;}

    MiddleNode* parentNode=new MiddleNode(fs,node.parent);
    Node parNode=parentNode->getMessage();
    
    int key=0;//the key of the element to be removed in parnode
    if(node.type==MIDDLE){
        //check left node's size and set brother
        TreeNode* leftNode=new MiddleNode(fs,node.leftSibling);
        TreeNode* rightNode=new MiddleNode(fs,node.position);
        Node lef=leftNode->getMessage();
        //check size
        if(lef.size+node.size!=max-1||lef.parent!=node.parent){
            delete leftNode;
            delete rightNode;
            delete parentNode;
            return false;
        }
        //build new keys and offsets and size       
        vector<int> keys(max,-1);
        vector<int> offsets(max+1,-1);
        key=rightNode->getKey(0);
        for(int i=0;i<lef.size;i++){keys[i]=leftNode->getKey(i);}
        for(int i=0;i<=lef.size;i++){offsets[i]=leftNode->getOffset(i);}
        for(int i=0;i<node.size;i++){keys[i+lef.size]=rightNode->getKey(i);}
        for(int i=0;i<node.size;i++){offsets[i+lef.size+1]=rightNode->getOffset(i+1);}
        lef.size=lef.size+node.size;
        //set new brother
        lef.rightSibling=node.rightSibling;
        if(node.rightSibling>0){
            Node rig(fs,node.rightSibling);
            rig.leftSibling=lef.position;
            rig.rewrite(fs);
        }

        delete leftNode;
        //rewrite
        leftNode=new MiddleNode(lef,keys,offsets);
        leftNode->rewrite(fs);
        node.type=MNONE;
        node.rewrite(fs);
        //set children
        for(int i=0;i<node.size;i++){
            setChildren(Node(fs,offsets[i+1+lef.size-node.size]),lef);
        }
        delete rightNode;
        delete leftNode;
    }else if(node.type==LEAF){
        TreeNode* leftNode=new LeafNode(fs,node.leftSibling);
        TreeNode* rightNode=new LeafNode(fs,node.position);
        Node lef=leftNode->getMessage();
        //check left node's size
        if(lef.size+node.size!=max-1||lef.parent!=node.parent){
            delete leftNode;
            delete rightNode;
            delete parentNode;
            return false;
        }
        //build new keys and offsets merge left
        vector<Data> datas(max,Data(-1,-1,0));
        key=rightNode->getData(0).key;
        for(int i=0;i<lef.size;i++){datas[i]=leftNode->getData(i);}
        for(int i=0;i<node.size;i++){datas[i+lef.size]=rightNode->getData(i);}
        lef.size+=node.size;
        //set brother
        lef.rightSibling=node.rightSibling;
        if(node.rightSibling>0){
            Node rig(fs,node.rightSibling); 
            rig.leftSibling=lef.position;
            rig.rewrite(fs);
        }
        //rewrite
        delete leftNode;
        leftNode=new LeafNode(lef,datas);
        leftNode->rewrite(fs);
        node.type=LNONE;
        node.rewrite(fs);
        delete rightNode;
        delete leftNode;
    }
    //check parent
    if(parNode.position==root&&parNode.size<=1){ 
        parNode.type=MNONE;
        parNode.rewrite(fs);
        root=parentNode->getOffset(0);
        fs.seekp(0,fs.beg);
        fs.write(reinterpret_cast<char*>(&root),sizeof(int));
        setChildren(Node(fs,parentNode->getOffset(0)),Node());
        return true;
    }
    int keyNum=parentNode->findKey(key);
    if(keyNum==-1){
        cout<<"par keyNum error:"<<key<<endl;
        delete parentNode;
        return true;
    }
    parentNode->removeKey(keyNum);
    parentNode->removeOffset(keyNum+1);
    parentNode->rewrite(fs);
    //parent's size==max/2 then process parent first
    if(parNode.size<=max/2 &&parNode.position!=root){
        bool flag=false;
        flag=rightRotate(Node(fs,parNode.leftSibling));
        if(!flag){
            //can't rightRotate so merge left
            flag=leftRotate(Node(fs,parNode.rightSibling));
        }
        if(flag){
            //rotation is over
            delete parentNode;
            parentNode=new MiddleNode(fs,parNode.parent);
        }else{
            flag=merge(parentNode->getMessage());
            if(!flag){merge(Node(fs,parNode.rightSibling));} 
        }
    }
    delete parentNode;
    return true;
}

bool BPlusTree::modify(Data data)
{
    LeafNode* node=findNode(data.key,root);
    if(node==NULL){return false;}

    int num=node->findKey(data.key);
    if(num<0){
        return false;
    }
    node->modify(num,data);
    node->rewrite(fs);
    delete node;
    return true;
}

vector<Data> BPlusTree::findRange(int low,int high)
{
    vector<Data> result;
    if(low>high){return result;} 
    LeafNode* myNode=findNode(low,root);
    while(true){ 
        Node node=myNode->getMessage();
        int start=myNode->findPosition(low);
        int end=myNode->findPosition(high);
        for(int i=start;i<end;i++){
            Data data=myNode->getData(i);
            result.push_back(data); 
        }
        if(node.rightSibling<0|| end < node.size ){
            break;
        }
        delete myNode;
        myNode=new LeafNode(fs,node.rightSibling);
    }
    delete myNode;
    return result;
}

