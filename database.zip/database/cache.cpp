#include <string>
#include <map>
#include<iostream>
#include "cache.h"

using namespace std;


int Cache::getSize() const
{
	return CacheMap.size();
}

//if has then return it or (0,"") otherwise
string Cache::find(int key)
{
	if (CacheMap.size() == 0)
	{
		return "";
	}
	map<int, string>::iterator it =CacheMap.find(key);
	if (it != CacheMap.end()){
		return it->second;
	}
	return "";
}

/*
if map has it and value is not "" then modify it 
if map has it and value is "" then delete it 
if map doesn't have it then add it 
*/
void Cache::push(int key, string str)
{
	if(key<0){return;}
	if (str == ""){
		CacheMap.erase(key);
		return ;
	}
	map<int, string>::iterator tmp = CacheMap.find(key);
	//check if it has this key
	if (tmp != CacheMap.end()){
		keys.push(key);
		CacheMap[key] = str;
	}else{
		CacheMap[key] =str;
		keys.push(key);
		if(CacheMap.size()>100){
			for(int i=0;i<50;i++){
				int num=keys.front();
				keys.pop();
				CacheMap.erase(num);
			}
		} 
	}
}

void Cache::clear()
{
	CacheMap.clear();
}

void Cache::print()
{
	cout<<"--------key-------str----------"<<endl;
	for(map<int,string>::iterator it=CacheMap.begin();it!=CacheMap.end();it++){
        cout<<"     "<<it->first<<"      "<<it->second<<endl;
    }
}