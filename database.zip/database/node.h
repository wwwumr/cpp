#ifndef NODE_H
#define NODE_H
#include<fstream>
#include<string>
#include<vector>

enum Node_Type{ MIDDLE , LEAF, MNONE,LNONE};
const int MMAX=59,LMAX=39;
class TreeNode;
class MiddleNode;
class LeafNode;

/*---------------------------------------------------------------------
*save basic massage of node
*/
struct Node{
    Node_Type type;
    int position;
    int parent;
    int leftSibling;
    int rightSibling;
    int size;

    Node():type(LEAF),position(-1),parent(-1),leftSibling(-1),rightSibling(-1),size(0){};
    Node(Node_Type t,int pos,int par,int left,int right,int s){
        type = t;
        position = pos;
        parent = par;
        leftSibling = left;
        rightSibling = right;
        size = s;
    }
    Node(std::fstream& fs,int pos){
        set(fs,pos);
    } 
    void set(std::fstream& fs,int pos){
        if(pos<0){
            type = LNONE;
            position = pos;
            parent = -1;
            leftSibling = -1;
            rightSibling = -1;
            size = 0;
            return;
        }
        fs.seekg(pos);
        fs.read(reinterpret_cast<char*>(&type),sizeof(int));
        fs.read(reinterpret_cast<char*>(&position),sizeof(int));
        fs.read(reinterpret_cast<char*>(&parent),sizeof(int));
        fs.read(reinterpret_cast<char*>(&leftSibling),sizeof(int));
        fs.read(reinterpret_cast<char*>(&rightSibling),sizeof(int));
        fs.read(reinterpret_cast<char*>(&size),sizeof(int));
    }
    void rewrite(std::fstream& fs){
        if(position<0){return;} 
        fs.seekp(position);
        fs.write(reinterpret_cast<char*>(&type),sizeof(int));
        fs.write(reinterpret_cast<char*>(&position),sizeof(int));
        fs.write(reinterpret_cast<char*>(&parent),sizeof(int));
        fs.write(reinterpret_cast<char*>(&leftSibling),sizeof(int));
        fs.write(reinterpret_cast<char*>(&rightSibling),sizeof(int));
        fs.write(reinterpret_cast<char*>(&size),sizeof(int));
    }
};
/*-------------------------------------------------------------------
*Data
*/
struct Data
{
    int key;
    int offset;
    int length;
    Data(int k,int o,int l):key(k),offset(o),length(l){};
};

/*----------------------------------------------------------------------
*abstract class used to be inheritanced
*/
class TreeNode{
protected:
    Node message;
public:
    TreeNode(){message=Node();};
    //only read message and check pos==-1
    TreeNode(std::fstream& fs,int pos);
    //return the location of key or return 0 otherwise
    virtual int findKey(int key){return -1;};
    //return suit offsetNum
    virtual int findPosition(int key){return -1;};
    virtual void rewrite(std::fstream& fs){return ;};
    virtual void rewriteMessage(std::fstream& fs){message.rewrite(fs);};
    Node getMessage(){return message;};
    void setMessage(Node m){message=m;};

    virtual void print(){};


    //remove the keyNum th key or offsetNum th offset and sort size--
    virtual int removeKey(int keyNum){return 0;}; 
    virtual int removeOffset(int offsetNum){return -1;};
    //insert key or offset into the location of num th or if size>MMAX+1 return false
    virtual bool insertKey(int keyNum,int key){return false;};
    virtual bool insertOffset(int offsetNum,int offset){return false;};
    //modify key unless the location is wrong
    virtual bool modifyKey(int keyNum,int key){return false;};
    //key is not in this node and return the location of next offset or return -1 otherwise
    virtual int findOffset(int offset){return -1;};
    //get the keyNum th key
    virtual int getKey(int keyNum){return -1;}
    //key is in this node and return next pos or return -1 otherwise
    virtual int getOffset(int offsetNum){return -1;};

    //insert new data into the location of keyNum
    virtual bool insert(int keyNum,Data data){return false;};
    //modify the keyNum th data into new data
    virtual bool modify(int keyNum,Data data){return false;};
    //remove the keyNum th data and return data
    virtual Data remove(int keyNum){return Data(-1,-1,0);};
    //return the data or (-1,0) otherwise
    virtual Data getData(int keyNum){return Data(-1,-1,0);};
    
};

/*--------------------------------------------------------------------
*MiddleNode
*/
class MiddleNode:public TreeNode{
private:
    std::vector<int> keys;
    std::vector<int> offsets;
public:
    MiddleNode();
    //check pos
    MiddleNode(std::fstream& fs,int pos);
    MiddleNode(Node me,std::vector<int> k,std::vector<int> off);

    int findKey(int key);
    //find the suit pos to insert 
    int findPosition(int key);
    void rewrite(std::fstream& fs);
    virtual void print();
    //remove the keyNum th key or offsetNum th offset and return the key or offset
    //consider root node doesn't have low limit
    //get offset and reset
    virtual std::vector<int> getVec(){return offsets;}
    virtual void setVec(std::vector<int> vec){offsets=vec;};
    virtual int removeKey(int keyNum); 
    virtual int removeOffset(int offsetNum);//size--
    //insert key or offset into the location of num th or if size>MMAX+1 return false
    virtual bool insertKey(int keyNum,int key);//size++
    virtual bool insertOffset(int offsetNum,int offset);
    //modify key unless the location is wrong
    virtual bool modifyKey(int keyNum,int key);
    //find the position of offset
    virtual int findOffset(int offset);
    //get the keyNum th key
    virtual int getKey(int keyNum);
    //key is in this node and return next pos or return -1 otherwise
    virtual int getOffset(int offsetNum);
};
/*--------------------------------------------------------------------
*LeafNode
*/
class LeafNode:public TreeNode{
private:
    std::vector< Data > datas;
public:
    LeafNode();
    LeafNode(std::fstream& fs,int pos);
    LeafNode(Node massage,std::vector< Data > datas);

    int findKey(int key);
    //find the suit pos to insert 
    int findPosition(int key);
    void rewrite(std::fstream& fs) ;
    virtual void print();
    //insert new data into the location of keyNum
    virtual bool insert(int keyNum,Data data);
    //modify the keyNum th data into new data
    virtual bool modify(int keyNum,Data data);
    //remove the keyNum th data and return data
    virtual Data remove(int keyNum);
    //return the data or (-1,0) otherwise
    virtual Data getData(int keyNum);
};

#endif