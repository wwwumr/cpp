#ifndef DATA_H
#define DATA_H
#include<vector>
#include<string>
#include<fstream>
#include"node.h"
#include"cache.h"
#include"freebin.h"
#include"bpt.h"


class DataBase
{
private:
    std::string indexFile;
    std::string dataFile;
    std::fstream dfs;
    BPlusTree* index;
    char* n;
    Cache cache;
    BuddyManager* buddyManager;
public:
    DataBase();
    DataBase(std::string indexFile,std::string dataFile);
    ~DataBase();
    //print datas
    void print(std::vector<std::pair<int,std::string> > datas);
    //insert
    bool insert(int key,std::string data);
    //remove
    bool remove(int key);
    //modify
    bool modify(int key,std::string data);
    //find
    std::string find(int key);
    void start();
};

#endif // !DATA_H