#include<fstream>
#include<iostream>
#include<string>
#include<vector>
#include"node.h"

using namespace std;

/*-------------------------------------------------------------------------------------
*TreeNode
*/
TreeNode::TreeNode(fstream& fs,int pos)
{
    if(pos>0){
        message=Node(fs,pos);
    }else{
        message=Node();
    }
}

/*------------------------------------------------------------------------------------------------
*MiddleNode
*/
MiddleNode::MiddleNode()
{
    message=Node();
    keys=vector<int>(MMAX+1,-1);
    offsets=vector<int>(MMAX+2,-1);
}

MiddleNode::MiddleNode(fstream& fs,int pos)
{
    //init 
    message=Node(fs,pos);
    keys=vector<int>(MMAX+1,-1);
    offsets=vector<int>(MMAX+2,-1);

    for(int i=0;i<MMAX+1;i++){
        fs.read(reinterpret_cast<char*>(&keys[i]),sizeof(int));
    }
    for(int i=0;i<=MMAX+1;i++){
        fs.read(reinterpret_cast<char*>(&offsets[i]),sizeof(int));
    }
}

MiddleNode::MiddleNode(Node me,vector<int> k,vector<int> off)
{
    this->message=me;
    keys=k;
    offsets=off;
}

int MiddleNode::findKey(int key)
{
    int low = 0;
	int high = message.size - 1;
	int mid;
	while (low <= high) 
	{
		mid = (low + high)/2;
        if(key==keys[mid]){
            return mid;
        }else if (key < keys[mid]){
			high = mid - 1;
		}else{
			low = mid + 1;
		}
	}
    return -1;
}

int MiddleNode::findPosition(int key)
{
    int low = 0;
    int size=message.size;
	int high =  size- 1;
	int mid;
    if(size==0){return 0;}
    if(key>keys[high]){return size;}
	while (low <= high) {
		mid = (high + low)/2;
        if(key==keys[mid]){
            return mid+1; 
        }else if (key < keys[mid]){
			high = mid - 1;
		}else{
			low = mid + 1;
		}
	}
	return  low <= size - 1 ? low : size -1;
}

void MiddleNode::rewrite(fstream& fs) 
{
    message.rewrite(fs);
    for(int i=0;i<MMAX+1;i++){
        fs.write(reinterpret_cast<char*>(&keys[i]),sizeof(int));
    }
    for(int i=0;i<MMAX+2;i++){
        fs.write(reinterpret_cast<char*>(&offsets[i]),sizeof(int)); 
    }
}

void MiddleNode::print()
{
    cout<<"------------middle node---------------"<<endl;
    cout<<"message:"<<message.type<<" "<<message.position<<" "<<message.parent<<" "
    <<message.leftSibling<<" "<<message.rightSibling<<" "
    <<message.size<<endl;
    cout<<"keys:"<<endl;
    for(int i=0;i<keys.size();i++){
        cout<<keys[i]<<" ";
    }
    cout<<endl<<"offsets:"<<endl;
    for(int i=0;i<offsets.size();i++){
        cout<<offsets[i]<<" ";
    }
    cout<<endl;
}

int MiddleNode::removeKey(int keyNum)
{
    if(keyNum<0||keyNum>=message.size){return -1;}

    int key=keys[keyNum];
    keys.erase(keys.begin()+keyNum);
    keys.push_back(-1);
    return key;
} 

int MiddleNode::removeOffset(int offsetNum)
{
    if(offsetNum<0||offsetNum>message.size){return -1;}

    int offset=offsets[offsetNum];
    offsets.erase(offsets.begin()+offsetNum);
    offsets.push_back(-1);
    message.size--;
    return offset;
}

bool MiddleNode::insertKey(int keyNum,int key)
{
    if(keyNum<0||keyNum>message.size||message.size>MMAX){return false;}

    keys.insert(keys.begin()+keyNum,key);
    keys.pop_back();
    message.size++;
    return true;
}

bool MiddleNode::insertOffset(int offsetNum,int offset)
{
    if(offsetNum<0||offsetNum>message.size){return false;}

    offsets.insert(offsets.begin()+offsetNum,offset);
    offsets.pop_back();
    return true;
}  

bool MiddleNode::modifyKey(int keyNum,int key)
{
    if(keyNum<0||keyNum>message.size){return false;}

    keys[keyNum]=key;
    return true;
}

int MiddleNode::findOffset(int offset)
{
    for(int i=0;i<offsets.size();i++){
        if(offset==offsets[i]){
            return i;
        }
    }
	return -1;
}

int MiddleNode::getKey(int keyNum)
{
    if(keyNum<0||keyNum>=message.size){return -1;}
    return keys[keyNum];
}

int MiddleNode::getOffset(int offsetNum)
{
    if(offsetNum<0||offsetNum>message.size){return -1;}
    return offsets[offsetNum];
}
/*--------------------------------------------------------------------
*LeafNode
*/
LeafNode::LeafNode()
{
    message=Node();
    datas=vector<Data>(LMAX+1,Data(-1,-1,0));
}

LeafNode::LeafNode(fstream& fs,int pos)
{
    //init massage
    message=Node(fs,pos);
    datas=vector<Data>(LMAX+1,Data(-1,-1,0));

    for(int i=0;i<LMAX+1;i++){
        fs.read(reinterpret_cast<char*>(&datas[i].key),sizeof(int));
    }
    for(int i=0;i<LMAX+1;i++){
        fs.read(reinterpret_cast<char*>(&datas[i].offset),sizeof(int));
    }
    for(int i=0;i<LMAX+1;i++){
        fs.read(reinterpret_cast<char*>(&datas[i].length),sizeof(int)); 
    }
}

LeafNode::LeafNode(Node m,std::vector<Data> d)
{
    message=m;
    datas=d;
    int sum=0;
    for(int i=0;i<datas.size();i++){
        if(datas[i].key!=-1){sum++;}
    }
    message.size=sum;
}

int LeafNode::findKey(int key)
{
    int low = 0;
	int high = message.size - 1;
	int mid;
	while (low <= high) 
	{
		mid = (low + high)/2;
        if(key==datas[mid].key){
            return mid;
        }else if (key < datas[mid].key){
			high = mid - 1;
		}else{
			low = mid + 1;
		}
	}
    return -1;
}

int LeafNode::findPosition(int key)
{
    int low = 0;
    int size=message.size; 
	int high = size - 1;
	int mid;
    if(size==0){return 0;} 
    if(key>datas[high].key){return size;}
	while (low <= high) {
		mid = (high + low)/2;
        if(key==datas[mid].key){
            return mid;
        }else if (key < datas[mid].key){
			high = mid - 1;
		}else{
			low = mid + 1;
		}
	}
	return  low <= size - 1 ? low : size -1;
}

void LeafNode::rewrite(fstream& fs) 
{
    message.rewrite(fs);

    for(int i=0;i<LMAX+1;i++){
        fs.write(reinterpret_cast<char*>(&datas[i].key),sizeof(int));
    }
    for(int i=0;i<LMAX+1;i++){
        fs.write(reinterpret_cast<char*>(&datas[i].offset),sizeof(int));
    }
    for(int i=0;i<LMAX+1;i++){
        fs.write(reinterpret_cast<char*>(&datas[i].length),sizeof(int));
    }
}

void LeafNode::print()
{
    cout<<"------------leaf node---------------"<<endl;
    cout<<"message:"<<message.type<<" "<<message.position<<" "<<message.parent<<" "
    <<message.leftSibling<<" "<<message.rightSibling<<" "
    <<message.size<<endl;
    cout<<"keys:"<<endl;
    for(int i=0;i<datas.size();i++){
        cout<<datas[i].key<<" ";
    }
    cout<<endl<<"offsets:"<<endl;
    for(int i=0;i<datas.size();i++){
        cout<<datas[i].offset<<" ";
    }
    cout<<endl<<"lengths:"<<endl;
    for(int i=0;i<datas.size();i++){
        cout<<datas[i].length<<" ";
    }
    cout<<endl;
}

bool LeafNode::insert(int keyNum,Data data)
{
    if(keyNum<0||keyNum>=LMAX+1||message.size>=LMAX+1){
        return false;
    }
    datas.insert(datas.begin()+keyNum,data);
    datas.pop_back();
    message.size++;
    return true;
}

bool LeafNode::modify(int keyNum,Data data)
{
    if(keyNum<0||keyNum>message.size){return false;}
    datas[keyNum]=data;
    return true;
}
    
Data LeafNode::remove(int keyNum)
{
    if(keyNum<0||keyNum>=message.size||message.size<=0){return Data(-1,-1,0);}

    Data data=datas[keyNum];
    datas.erase(datas.begin()+keyNum);
    datas.push_back(Data(-1,-1,0));
    message.size--;
    return data;
}

Data LeafNode::getData(int keyNum)
{
    if(keyNum<0||keyNum>message.size){return Data(-1,-1,0);}

    return datas[keyNum];
}