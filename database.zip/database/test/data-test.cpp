#include<iostream>
#include<cstdlib>
#include<ctime>
#include<string>
#include<fstream>
#include"../node.h"
#include"../cache.h"
#include"../freebin.h"
#include"../bpt.h" 

using namespace std;

std::string indexFile="test.txt";
std::string dataFile="new.txt";
char s='\n';
char* n=&s;
std::fstream dfs;
BPlusTree* index;
Cache cache;
BuddyManager* buddyManager;

void print(Data data)
{
    cout<<data.key<<" "<<data.offset<<" "<<data.length<<endl;
}

void display(){
    fstream fs("test.txt",ios::in|ios::out|ios::binary);
    fs.seekg(0,fs.end);
    int len=fs.tellg();
    fs.seekg(0,fs.beg);
    cout<<"display--------------------"<<endl;
    for(int i=0;i<len/4;i++){
        int num=0;
        fs.read(reinterpret_cast<char*>(&num),sizeof(int));
        cout<<i<<":"<<num<<endl;
    }
    cout<<"----------------------"<<endl;
}


string randStr(){
    string str="";
    int len=rand()%9+1;
    for(int i=0;i<len;i++){
        str+='a'+rand()%26;
    }
    return str;
}

string find(int key)
{
    string str=cache.find(key);
    if(str!=""){return str;}

    Data data=index->find(key);
    if(data.offset<0||data.length<=0){
        return "";
    }
    dfs.seekg(data.offset);
    char* s=new char[data.length];
    s[data.length-1]='\0';
    dfs.read(s,data.length-1);
    str=s; 
    delete[] s;
    cache.push(key,str);
    return str;
}

bool insert(int key,string data)
{
    if(key<0||data==""){return false;}

    cache.push(key,data); 
    dfs.seekg(0,dfs.end); 
    int offset=dfs.tellg();
    Data d =index->find(key);
    if(d.key<0||d.offset<0||d.length<=0){
        index->insert(Data(key,offset,data.length()+1));
        dfs.seekp(0,dfs.end);
        dfs.write(data.c_str(),data.length());
        dfs.write(n,sizeof(char));
    }else{
        dfs.seekp(0,dfs.end);
        dfs.write(data.c_str(),data.length());
        dfs.write(n,sizeof(char));
        index->modify(Data(key,offset,data.length()+1));
        buddyManager->addRemove(d);
    }
    return true;
}

bool remove(int key)
{
    if(key<0){return false;}

    string str=cache.find(key);
    if(str!=""){cache.push(key,"");}

    Data d = index->remove(key);
    if(d.key<0||d.offset<0||d.length<=0){
        return false;
    }
    buddyManager->addRemove(d);
    return true;
}

bool modify(int key,string data){
    if(key<0||data==""){return false;}

    cache.push(key,data);

    Data d = index->find(key);
    if(d.key<0||d.offset<0||d.length<=0){
        return false;
    }else{
        dfs.seekp(0,dfs.end);
        int offset=dfs.tellp();
        dfs.write(data.c_str(),data.length());
        dfs.write(n,sizeof(char));
        index->modify(Data(key,offset,data.length()+1));
        buddyManager->addRemove(d);
    }
    return true;
}

int main()
{
    //init
    index=new BPlusTree(indexFile);
    dfs.open(dataFile.c_str(),ios::in|ios::out|ios::binary|ios::app);
    dfs.close();
    dfs.open(dataFile.c_str(),ios::in|ios::out|ios::binary);
    cache=Cache();
    buddyManager=new BuddyManager(indexFile,dataFile);
    //----------------------------------------
    srand((unsigned)time(NULL));
    for(int i=0;i<100;i++){
        string str=randStr();
        insert(i,str);
    }

    for(int i=0;i<100;i++){
        string str=find(i);
        cout<<i<<":"<<str<<endl;
    }
    cout<<find(5)<<endl;
    cout<<find(27)<<endl;
    cout<<find(53)<<endl;
    cout<<find(66)<<endl;
    cout<<find(97)<<endl;
    cout<<find(21)<<endl;
    remove(21);
    cout<<find(21)<<endl;
    insert(21,"abcde");
    cout<<find(21)<<endl;
    modify(21,"efgh");
    cout<<find(21)<<endl;

    //decrease-----------------------
    dfs.close();
    delete index;
    delete buddyManager;
    return 0;
}
