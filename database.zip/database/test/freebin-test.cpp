#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<cstdlib>
#include<ctime>
#include"../bpt.h"

using namespace std;

string indexFile="test.txt";
string dataFile="new.txt";
const int BUDDYMAX=20;
//save offset change in b tree
vector<std::pair<int,int> > positions;
vector<int> pRank;
//save removed or modified offsets in data file
vector<std::pair<int,int> > removes;
vector<int> rRank;

int getOffset(int offset,int mode);
int findSuit(int offset,const vector<pair<int,int> >&offsets);


void display(string str){
    fstream fs(str.c_str(),ios::binary|ios::in|ios::out);
    fs.seekg(0,fs.end);
    int len=fs.tellg();
    fs.seekg(0,fs.beg);
    for(int i=0;i<len/4;i++){
        int num=0;
        fs.read(reinterpret_cast<char*>(&num),sizeof(int));
        cout<<i<<":"<<num<<endl;
    }
}

void getRank(vector<pair<int,int> >&offsets,vector<int>& rank)
{
    int size=offsets.size();
    rank=vector<int>(size+1,0);
    for(int i=0;i<size;i++){
        for(int j=i+1;j<size;j++){
            if(offsets[i].first>offsets[j].first){
                pair<int,int> unit=offsets[i];
                offsets[i]=offsets[j];
                offsets[j]=unit;
            }
        }
    }
    for(int i=0;i<size;i++){
        rank[i+1]=rank[i]+offsets[i].second;
    }
}

int renewNode(fstream& ifs,fstream& ofs,int pos)
{
    Node_Type type;
    ifs.seekg(pos);
    ifs.read(reinterpret_cast<char*>(&type),sizeof(int));
    int size=(type==MIDDLE||type==MNONE)?(2*(MMAX+1)+7)*sizeof(int) :(3*(LMAX+1)+6)*sizeof(int);
    if(type==MNONE){
        TreeNode* m=new MiddleNode(ifs,pos);
        delete m;
    }else if(type==LNONE){
        TreeNode* l=new LeafNode(ifs,pos);
        delete l;
    }else if(type==MIDDLE){
        ofs.write(reinterpret_cast<char*>(&type),sizeof(int));
        for(int i=1;i<size/sizeof(int);i++){
            int num=0;
            ifs.read(reinterpret_cast<char*>(&num),sizeof(int));
            if((i<5 && i>0 )||i>=MMAX+6){num=getOffset(num,0);}
            ofs.write(reinterpret_cast<char*>(&num),sizeof(int));
        }
    }else if(type==LEAF){
        ofs.write(reinterpret_cast<char*>(&type),sizeof(int));
        for(int i=1;i<size/sizeof(int);i++){
            int num=0;
            ifs.read(reinterpret_cast<char*>(&num),sizeof(int));
            if(i<5 && i>0 ){
                num=getOffset(num,0);
            }
            //if(i>=LMAX+6 && i<2*LMAX+7){num=getOffset(num,1);}
            ofs.write(reinterpret_cast<char*>(&num),sizeof(int));
        }
    }
    pos+=size;
    return pos;
}

void initPos(fstream& ifs)
{
    ifs.seekg(0,ifs.end);
    int len=ifs.tellg();
    int pos=0;
    ifs.seekg(0,ifs.beg);
    int num;
    ifs.read(reinterpret_cast<char*>(&num),sizeof(int));
    pos+=sizeof(int); 
    while(pos<len){
        Node_Type type;
        ifs.read(reinterpret_cast<char*>(&type),sizeof(int));
        int size=(type==MIDDLE||type==MNONE)?(2*(MMAX+1)+7)*sizeof(int) :(3*(LMAX+1)+6)*sizeof(int);
        if(type==MNONE){
            positions.push_back(make_pair(pos,size));
            pos+=size;
            ifs.seekg(pos);
        }else if(type==LNONE){
            positions.push_back(make_pair(pos,size));
            pos+=size;
            ifs.seekg(pos);
        }else{
            pos+=size;
            ifs.seekg(pos);
        }
    }
    getRank(positions,pRank);
    getRank(removes,rRank);
}

bool renewIndex()
{
    fstream ifs(indexFile.c_str(),ios::binary|ios::in|ios::out|ios::app);
    ifs.close();
    ifs.open(indexFile.c_str(),ios::binary|ios::in|ios::out);
    ifs.seekg(0,ifs.end);
    int len=ifs.tellg();
    int pos=0;
    if(len<sizeof(int)){return false;}
    
    initPos(ifs);
    string outPath="test1.txt";
    fstream ofs(outPath.c_str(),ios::binary|ios::in|ios::out|ios::app);
    ofs.seekp(0,ofs.beg);
    ifs.seekg(0,ifs.beg);
    int num=0;
    ifs.read(reinterpret_cast<char*>(&num),sizeof(int));
    num=getOffset(num,0); 
    ofs.write(reinterpret_cast<char*>(&num),sizeof(int));
    pos+=sizeof(int);
    while(pos<len){
        pos=renewNode(ifs,ofs,pos); 
    }
    remove(indexFile.c_str());
    rename(outPath.c_str(),indexFile.c_str());
    ofs.close();
    ifs.close();
    return true;
}

int findSuit(int offset,const vector<pair<int,int> >&offsets)
{
    int low = 0;
    int size=offsets.size(); 
	int high = size - 1;
	int mid;
    if(offset > offsets[size-1].first ){return size;} 
	while (low <= high) {
		mid = (high + low)/2;
        if(offset==offsets[mid].first){
            return mid;
        }else if (offset < offsets[mid].first){
			high = mid - 1;
		}else{
			low = mid + 1;
		}
	}
	return  (low <= size - 1) ? low : size -1;
}

int getOffset(int offset,int mode)
{
    if(offset<0){return offset;}

    if(mode==0){
        cout<<offset<<":";
        int num=findSuit(offset,positions);
        cout<<offset-pRank[num]<<endl;
        return offset-pRank[num];
    }else{
        int num=findSuit(offset,removes);
        return offset-rRank[num];
    }
}

bool addRemove(Data data)
{
    removes.push_back(make_pair(data.offset,data.length));
    if(removes.size()>BUDDYMAX){
        return true;
    }
    return false;
}

bool renewDatas()
{
    fstream dfs(dataFile.c_str(),ios::binary|ios::in|ios::out|ios::app);
    dfs.close();
    dfs.open(dataFile.c_str(),ios::binary|ios::in|ios::out);
    dfs.seekg(0,dfs.end);
    int len=dfs.tellg();
    if(len<sizeof(int)){return false;}

    string outPath="./data/data1.txt";
    fstream ofs(outPath.c_str(),ios::binary|ios::in|ios::out|ios::app);
    dfs.seekg(0,dfs.end);
    int end=dfs.tellg();
    ofs.seekp(0,ofs.beg);
    dfs.seekg(0,dfs.beg);
    //init offsets and lengths
    int size=removes.size();

    //offset is used to indicate the position of file,pos indicate the position of vector 
    int offset=0;
    for(int pos = 0;pos <=size;pos++){
        char* part;
        dfs.read(part,removes[pos].first-offset);
        offset=removes[pos].first; 
        ofs.write(part,removes[pos].first-offset);
        dfs.seekg(removes[pos].second,dfs.cur);
        offset+=removes[pos].second;
    }
    char* part;
    dfs.read(part,end-offset); 
    ofs.write(part,end-offset);
    removes.clear();
    rRank.clear();
    remove(dataFile.c_str());
    rename(outPath.c_str(),indexFile.c_str());
    dfs.close();
    ofs.close();
    return true;
}

int main()
{
    string str="test.txt";
    srand((unsigned)time(NULL));
    BPlusTree* index=new BPlusTree("test.txt");
    for(int i=0;i<100;i++){
        index->insert(Data(i+1,i+1,i+1));
    }  
    for(int i=30;i<=50;i++){
        addRemove(index->remove(i));
    }
    for(int i=108;i<127;i++){
        index->insert(Data(i,i,i));
    }
    delete index;
    //display(str);
    renewIndex();
    //display(str);
    
    remove("test.txt");
}