#include<iostream>
#include<vector>
#include<cstdlib> 
#include<ctime>
#include<algorithm>

using namespace std;

int findOffset(vector<int> keys,int key)
{
    int low = 0;
    int size=keys.size();
	int high = size - 1;
	int mid;
    if(key>keys[high]){return size;}
	while (low <= high) {
		mid = low + ((high - low) >> 1);
		if (key < keys[mid]) 
		{
			high = mid - 1;
		}
		else 
		{
			low = mid + 1;
		}
	}
	return  low <= size - 1 ? low : size -1;
}

int findPosition(vector<int> keys,int key)
{
    int low = 0;
    int size=keys.size();
	int high = size - 1;
	int mid;
	while (low <= high) {
		mid = low + ((high - low) >> 1);
		if (key < keys[mid]) 
		{
			high = mid - 1;
		}
		else 
		{
			low = mid + 1;
		}
	}
	return - 1;
}

vector<int> random_vector()
{
    srand((unsigned)time(NULL));
    int size=(rand()%50);
    while(size==0){
        size=(rand()%50);
    }
    
    vector<int> random_vec(size,-1);
    for(int i=0;i<size;i++){
        random_vec[i]=rand()%100;
    }
    sort(random_vec.begin(),random_vec.end());
    cout<<"vec:[";
    for(int i=0;i<size;i++){
        cout<<random_vec[i]<<" ";
    }
    cout<<"]  ";
    return random_vec;
}

void repeat(int times)
{
    vector<int> keys=random_vector();
    srand((unsigned)time(NULL));
    int num=rand()%100;
    cout<<endl<<"findposition:"<<num<<" ";
    int pos=findPosition(keys,num);
    if(pos!=-1){cout<<pos<<":"<<keys[pos];}
    cout<<endl;

    num=rand()%keys.size();
    cout<<"findOffset:"<<keys[num]<<" ";
    pos=findOffset(keys,keys[num]);
    cout<<pos<<":"<<keys[pos-1]<<" "<<keys[pos]<<endl;

    num=rand()%1000;
    cout<<"findOffset:"<<num<<" ";
    pos=findOffset(keys,num);
    cout<<pos<<":"<<keys[pos-1]<<" "<<keys[pos]<<endl;
}

int main()
{
    repeat(10);
}