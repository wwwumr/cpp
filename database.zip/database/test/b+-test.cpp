#include<iostream>
#include<fstream>
#include<vector>
#include<cstdlib>
#include<ctime>
#include"../bpt.h"

using namespace std;

void print(Data data)
{
    cout<<data.key<<" "<<data.offset<<" "<<data.length<<endl;
}

int main()
{
    srand((unsigned)time(NULL));
    BPlusTree* index=new BPlusTree("./test.txt");
    for(int i=0;i<50;i++){
        index->insert(Data(i+1,i+1,i+1));
    }
    print(index->find(9));
    vector<Data> vec=index->findRange(3,12);
    for(int i=0;i<vec.size();i++){
        print(vec[i]);
    }
    index->modify(Data(3,4,5));
    index->modify(Data(11,4,5));
    print(index->find(3));
    print(index->find(11));
    print(index->remove(5));
    print(index->remove(15));
    print(index->find(5));
    print(index->find(15));
    delete index; 
}