#include<iostream>
#include<string>
#include<vector>
#include<cstdlib>
#include<ctime>
#include<map>
#include"../cache.h"

using namespace std;

string randstr()
{
    int length=rand()%9+1;
    string str="";
    for(int i=0;i<length;i++){
        char c='a'+rand()%26;
        str+=c;
    }
    return str;
}

int main()
{
    Cache cache;
    vector<string> names;
    //init cache
    srand((unsigned)time(NULL));
    for(int i=0;i<240;i++){
        string str=randstr();
        names.push_back(str);
        cache.push(i,str);
    }
    cout<<"vector:[";
    for(int i=0;i<200;i++){
        cout<<names[i];
        if(i<199){
            cout<<",";
        }
    }
    cout<<"]"<<endl;
    //test print
    cache.print();
    //test find
    cout<<"find-test--------------------------------------"<<endl;
    int start=150;
    for(int i=0;i<20;i++){
        int r=150+rand()%cache.getSize();
        string findResult=cache.find(r);
        cout<<"    "<<r<<"    "<<findResult<<endl;
    }
    //test push
    cout<<"push-test------------------------------------------"<<endl;
    for(int i=0;i<10;i++){
        cache.push(start+i,"");
    }
    for(int i=10;i<20;i++){
        string str=randstr();
        cache.push(start+i,str);
    }
    cache.print();
    cout<<"clear-test------------------------------------------"<<endl;
    cache.clear();
    cache.print();
    return 0; 
}