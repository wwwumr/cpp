#include<iostream>
#include<fstream>

using namespace std;

int main()
{
    fstream fs("test.txt",ios::binary|ios::in|ios::out|ios::app);
    fstream ofs("new.txt",ios::out|ios::app);
    fs.seekg(0,fs.end);
    int textLength=fs.tellg();
    fs.seekg(0,fs.beg);
    ofs.seekp(0,ofs.beg);
    
    for(int i=0;i<textLength/sizeof(int);i++){
        int x=0;
        fs.read(reinterpret_cast<char*>(&x),sizeof(int));
        cout<<i<<":"<<x<<endl;
        ofs<<x;
    }
    fs.close();
    ofs.close();
    return 0;
}