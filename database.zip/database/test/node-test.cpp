#include<fstream>
#include<iostream>
#include<string>
#include<vector>
#include<cstdlib>
#include<ctime>
#include"../node.h"

using namespace std;

void copy(fstream& fs)
{
    fstream ofs;
    ofs.open("new.txt",ios::binary|ios::in|ios::out|ios::app);
    ofs.close();
    ofs.open("new.txt",ios::binary|ios::in|ios::out);
    fs.seekg(0,fs.end);
    int len=fs.tellg();
    fs.seekg(0,fs.beg);
    ofs.seekp(0,ofs.beg);
    for(int i=0;i<len/4;i++){
        int num=5;
        fs.read(reinterpret_cast<char*>(&num),sizeof(int));
        ofs<<num<<" ";
    }
    ofs.close();
}

void display(fstream& fs){
    fs.seekg(0,fs.end);
    int len=fs.tellg();
    fs.seekg(0,fs.beg);
    for(int i=0;i<len/4;i++){
        int num=0;
        fs.read(reinterpret_cast<char*>(&num),sizeof(int));
        cout<<i<<":"<<num<<endl;
    }
}

int main()
{
    //node test
    fstream fs;
    fs.open("test.txt",ios::binary|ios::in|ios::out|ios::app);
    fs.close();
    fs.open("test.txt",ios::binary|ios::in|ios::out);
    //test node
    Node n;
    n.position=0;
    n.rewrite(fs);
    copy(fs);
    //test MiddleNode
    MiddleNode* m=new MiddleNode();
    srand((unsigned)time(NULL));
    cout<<"insert-test------------------"<<endl;
    n.type=MIDDLE;
    m->setMessage(n);
    m->insertOffset(0,2);
    for(int i=0;i<MMAX;i++){
        int r=rand()%20;
        int offset=rand()%30;
        m->insertKey(i,r);
        m->insertOffset(i+1,r);
    }
    m->rewrite(fs);
    copy(fs);
    display(fs);
    cout<<endl<<"remove-test------------------"<<endl;
    int x=m->removeKey(2);
    int y=m->removeOffset(3);
    cout<<"  "<<x<<"  "<<y<<endl;
    m->rewrite(fs);
    display(fs);
    cout<<endl<<"modify-test------------------"<<endl;
    m->modifyKey(4,6);
    m->rewrite(fs);
    display(fs);
    cout<<endl<<"find-test------------------"<<endl;
    cout<<endl<<"please input offset:";
    int offset;
    cin>>offset;
    cout<<m->findOffset(offset);
    cout<<endl<<"getkey-test------------------"<<endl;
    cout<<0<<"   "<<m->getKey(0)<<endl;
    cout<<6<<"   "<<m->getKey(6)<<endl;
    cout<<12<<"   "<<m->getKey(12)<<endl;
    cout<<22<<"   "<<m->getKey(22)<<endl;
    cout<<MMAX<<"   "<<m->getKey(MMAX)<<endl; 
    delete m;
    //-----------------------------------
    LeafNode* l=new LeafNode();
    int len=(7+2*MMAX)*sizeof(int);
    n.position=len;
    n.type=LEAF;
    l->setMessage(n);
    l->rewrite(fs);
    cout<<endl<<"insert-test------------------"<<endl;
    for(int i=0;i<LMAX;i++){ 
        int r=rand()%20;
        int offset=rand()%30;
        l->insert(i,Data(i,r,offset));
    }
    l->rewrite(fs);
    display(fs);
    cout<<endl<<"remove-test------------------"<<endl;
    Data d=l->remove(5);
    cout<<"  "<<d.key<<"  "<<d.offset<<"  "<<d.length<<endl;
    l->rewrite(fs);
    display(fs);
    cout<<endl<<"modify-test------------------"<<endl;
    l->modify(5,Data(1,2,3));
    l->rewrite(fs);
    d=l->getData(5);
    cout<<"  "<<d.key<<"  "<<d.offset<<"  "<<d.length<<endl;
    delete l;
    fs.close();
    return 0;
}