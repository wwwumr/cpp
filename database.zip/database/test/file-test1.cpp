#include<iostream>
#include<fstream>

using namespace std;

int main()
{
    fstream fs;
    fs.open("test.txt",ios::binary|ios::in|ios::out);
    fs.seekg(0,fs.end);
    int textLength=fs.tellg();
    fs.seekp(0,fs.beg);
    //if(textLength==0){
        
        for(int i=0;i<2;i++){
            int x=0;
            fs.write(reinterpret_cast<char*>(&x),sizeof(int));
        }
        
        for(int i=0;i<3;i++){
            int x=-1;
            fs.write(reinterpret_cast<char*>(&x),sizeof(int));
        }
        
        for(int i=0;i<121;i++){
            int x=0;
            fs.write(reinterpret_cast<char*>(&x),sizeof(int));
        }
    /*}else{
        int root;
        fs.read(reinterpret_cast<char*>(&root),sizeof(int));
        cout<<root;
    }*/
    fs.close();
    return 0;
}