#ifndef FREEBIN_H
#define FREEBIN_H
#include<fstream>
#include<string>
#include<vector>
#include"node.h"

/*
*read index file and get useless node so that we can change position in index
*when remove or modify we can get removes and modifys so that we can copy a new data file
*when operation is up to 20 we flush them
*/
class BuddyManager
{
private:
    std::string indexFile;
    std::string dataFile;
    //save offset change in b tree
    std::vector<std::pair<int,int> > positions;
    std::vector<int> pRank;
    //save removed or modified offsets in data file
    std::vector<std::pair<int,int> > removes;
    std::vector<int> rRank;
    
public:
    BuddyManager();
    BuddyManager(std::string index,std::string datas);
    ~BuddyManager();

    //add operations and judge if list is full
    bool addRemove(Data data); 
    //init positions
    void initPos(std::fstream& ifs);
    //get rank
    void getRank(std::vector<std::pair<int,int> >& offsets,std::vector<int>& rank);
    //renew file by deleting empty node or useless data
    bool renewIndex();
    //renew node into copy file
    int renewNode(std::fstream& ifs,std::fstream& ofs,int pos);
    //remeber the datas removed and don't copy them
    bool renewDatas();
    //find suit position
    int findSuit(int offset,const std::vector<std::pair<int,int> >& offsets);
    //get new offset choose mode to tell the file type
    int getOffset(int offset,int mode);
    //get the tail of data file
    int getTail();
};

#endif // !FREEBIN_H
