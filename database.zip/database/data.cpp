#include<string>
#include<iostream>
#include<vector>
#include"data.h" 

using namespace std;

DataBase::DataBase()
{
    indexFile="./data/index.txt";
    dataFile="./data/data.txt";
    dfs.open(dataFile.c_str(),ios::in|ios::out|ios::binary|ios::app);
    dfs.close();
    dfs.open(dataFile.c_str(),ios::in|ios::out|ios::binary);
    index=new BPlusTree(indexFile.c_str());
    cache=Cache();
    buddyManager=new BuddyManager();
    char s='\n';
    n=&s;
}

DataBase::DataBase(string indexFile,string dataFile)
{
    this->indexFile=indexFile;
    this->dataFile=dataFile;
    index=new BPlusTree(indexFile);
    dfs.open(dataFile.c_str(),ios::in|ios::out|ios::binary|ios::app);
    dfs.close();
    dfs.open(dataFile.c_str(),ios::in|ios::out|ios::binary);
    cache=Cache();
    char s='\n';
    n=&s;
    buddyManager=new BuddyManager(indexFile,dataFile);
}

DataBase::~DataBase()
{
    dfs.close();
    delete index;
    delete buddyManager;
}

void DataBase::start()
{
    cout<<"-----------------DataBase start------------------"<<endl;
    cout<<"The Basic Instructions: INSERT REMOVE FIND MODIFY"<<endl;
    cout<<"---'HLPE' TO FIND MORE---------'QUIT' To Quit----"<<endl;
    string str;
    cin>>str;
    while(str!="QUIT"){ 
        if(str=="HLPE"){
            cout<<"-----------------HELP------------------"<<endl;
            cout<<"INSERT:This instruction can insert things"<<endl;
            cout<<"EXAMPLE: INSERT 5 TONY"<<endl;
            cout<<"REMOVE:This instruction can remove data"<<endl;
            cout<<"EXAMPLE: REMOVE 5"<<endl;
            cout<<"FIND:This instruction can find data by key"<<endl;
            cout<<"EXAMPLE: FIND 5"<<endl;
            cout<<"MODIFY:This instruction can modify data"<<endl;
            cout<<"EXAMPLE: MODIFY 5 MARRY"<<endl;
            cout<<"-----------------------------------------"<<endl;
        } else if(str=="INSERT"){
            int key;
            string val;
            cin>>key>>val;
            insert(key,val);
        }else if(str=="REMOVE"){
            int key;
            cin>>key;
            remove(key);
        }else if(str=="FIND"){
            int key;
            cin>>key;
            cout<<find(key)<<endl;
        }else if(str=="MODIFY"){
            int key;
            string val;
            cin>>key>>val;
            modify(key,val); 
        }else{
            cout<<"This is not an instruction,please input again"<<endl;
        }
        cin>>str;
    }
}


string DataBase::find(int key)
{
    string str=cache.find(key);
    if(str!=""){return str;}

    Data data=index->find(key);
    if(data.offset<0||data.length<=0){
        return "";
    }
    dfs.seekg(data.offset);
    char* s=new char[data.length];
    s[data.length-1]='\0';
    dfs.read(s,data.length-1);
    str=s; 
    delete[] s;
    cache.push(key,str);
    return str;
}

bool DataBase::insert(int key,string data)
{
    if(key<0||data==""){return false;}

    cache.push(key,data); 
    dfs.seekg(0,dfs.end); 
    int offset=dfs.tellg();
    Data d =index->find(key);
    if(d.key<0||d.offset<0||d.length<=0){
        index->insert(Data(key,offset,data.length()+1));
        dfs.seekp(0,dfs.end);
        dfs.write(data.c_str(),data.length());
        dfs.write(n,sizeof(char));
    }else{
        dfs.seekp(0,dfs.end);
        dfs.write(data.c_str(),data.length());
        dfs.write(n,sizeof(char));
        index->modify(Data(key,offset,data.length()+1));
        buddyManager->addRemove(d);
    }
    return true;
}

bool DataBase::remove(int key)
{
    if(key<0){return false;}

    string str=cache.find(key);
    if(str!=""){cache.push(key,"");}

    Data d = index->remove(key);
    if(d.key<0||d.offset<0||d.length<=0){
        return false;
    }
    buddyManager->addRemove(d);
    return true;
}

bool DataBase::modify(int key,string data){
    if(key<0||data==""){return false;}

    cache.push(key,data);

    Data d = index->find(key);
    if(d.key<0||d.offset<0||d.length<=0){
        return false;
    }else{
        dfs.seekp(0,dfs.end);
        int offset=dfs.tellp();
        dfs.write(data.c_str(),data.length());
        dfs.write(n,sizeof(char));
        index->modify(Data(key,offset,data.length()+1));
        buddyManager->addRemove(d);
    }
    return true;
}
