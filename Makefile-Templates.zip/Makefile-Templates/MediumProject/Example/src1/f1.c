#include "f1.h"

int f1(int a, int b) { return a + b; }