#include "f4.h"

int f4(int a, int b) { return a; }