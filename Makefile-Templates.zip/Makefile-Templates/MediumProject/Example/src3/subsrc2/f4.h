#ifndef __F4_H__
#define __F4_H__

int f4(int a, int b);

#endif