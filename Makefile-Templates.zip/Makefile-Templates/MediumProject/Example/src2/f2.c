#include "f2.h"

int f2(int a, int b) { return a - b; }